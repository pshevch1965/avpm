"""
Business logic services.
"""