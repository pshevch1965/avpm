from __future__ import annotations

from avpm.backends.adguard import AdGuardBackend


def run(args) -> int:
    backend = AdGuardBackend()

    status = backend.status()

    print(status.raw)

    return 0


def register(subparsers) -> None:
    parser = subparsers.add_parser(
        "status",
        help="Show VPN status",
    )

    parser.set_defaults(func=run)